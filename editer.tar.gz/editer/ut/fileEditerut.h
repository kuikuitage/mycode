#include <memory>
#include <QTest>
#include "fileEditer.h"

class fileEditerUt : public QObject
{
    Q_OBJECT

private slots:
    void initTestCase();
    void cleanupTestCase();
    void init();
    void cleanup();
    void test1();
    void test2();
private:
    std::unique_ptr<fileEditer> m_upfileEditer = nullptr;
};