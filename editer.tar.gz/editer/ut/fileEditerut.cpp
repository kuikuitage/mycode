#include <iostream>
#include <QDebug>
#include "fileEditerut.h"
#include "ui_fileEditer.h"
#include "ui_about.h"

void fileEditerUt::initTestCase()
{
    std::cout << "  test start" << std::endl;
}

void fileEditerUt::cleanupTestCase()
{
    std::cout << "  test end" << std::endl;
}

void fileEditerUt::init()
{
    std::cout << "      init start" << std::endl;
    m_upfileEditer = std::make_unique<fileEditer>();
}

void fileEditerUt::cleanup()
{
    std::cout << "      cleanup start" << std::endl;
    m_upfileEditer.reset();
}


void fileEditerUt::test1()
{
    std::cout << "          test 1 start" << std::endl;
    //QTest::Click(m_upfileEditer->ui->aboutQt, Qt::Key_Left);
    m_upfileEditer->ui->aboutQt->trigger();

    // QKeyEvent tabKey(QEvent::KeyPress, Qt::Key_Enter, Qt::NoModifier);
    // qDebug() << "gwgwgww" << qApp->activeWindow()->objectName();
    // QCoreApplication::sendEvent(qApp->activeWindow(), &tabKey);

    QTest::keyClicks(m_upfileEditer->ui->fileContent, "hello world");
    qDebug() << m_upfileEditer->ui->fileContent->toPlainText();
    std::cout << "          test 1 end" << std::endl;
}

void fileEditerUt::test2()
{
    std::cout << "          test 2 start" << std::endl;

    std::cout << "          test 2 end" << std::endl;
}