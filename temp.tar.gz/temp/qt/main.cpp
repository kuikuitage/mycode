#include <QApplication>
#include "PanelItem.hpp"
#include <gtest/gtest.h>
#include "test.hpp"

int main(int argc,char ** argv)
{
  QApplication app(argc,argv);

  ::testing::InitGoogleTest(&argc,argv);
  RUN_ALL_TESTS();

  GPanelItem * panelItem = new GPanelItem();
  panelItem->show();

  return app.exec();
}
